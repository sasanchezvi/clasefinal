package core

const (
	Name    = "bettercap"
	Version = "2.41.0"
	Author  = "Simone 'evilsocket' Margaritelli"
	Website = "https://bettercap.org/"
)
