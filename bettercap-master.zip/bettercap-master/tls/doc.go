// Package tls contains code for TLS certificate generation and signing.
package tls
